﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String ConStr =( @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Rehan\OneDrive\Desktop\Client\Client\Client.mdf;Integrated Security=True");
        SqlConnection connection;
        SqlCommand command;
        SqlDataAdapter adapter;
       SqlDataReader dataReader;
        DataSet data;

        private void btnInsert_Click(object sender, EventArgs e)
        {
            connection.Open();
            connection = new SqlConnection();
            adapter = new SqlDataAdapter();
            data = new DataSet();
            String sql = $"INSERT INTO dbo.CLIENT VALUES ('{txtUserName.Text}','{txtFirstName.Text}','{txtLastName.Text}','{txtPassword.Text}','{txtActiveOrNot.Text}','{txtDateJoined.Text}','{txtDatePasswordChanged.Text})";
            command = new SqlCommand(sql, connection);
            adapter.Fill(data, "CLIENT");
            adapter.SelectCommand = command;
            dataGridView1.DataSource = data;
            dataGridView1.DataMember = "Client";
            connection.Close();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            connection.Open();
            adapter = new SqlDataAdapter();
            data = new DataSet();
            String sql = "SELECT * FROM dbo.CLIENT";
            command = new SqlCommand(sql, connection);
            adapter.Fill(data, "CLIENT");
            adapter.SelectCommand = command;
            dataGridView1.DataSource = data;
            dataGridView1.DataMember = "Client";
            connection.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            connection.Open();
            string delete_query = "DELETE FROM dbo.CLIENT WHERE LastName= " + txtLastName.Text + "";
            SqlCommand command = new SqlCommand(delete_query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.DeleteCommand = command;
            adapter.DeleteCommand.ExecuteNonQuery();
            dataGridView1.DataSource = data;
            dataGridView1.DataMember = "Client";
            connection.Close();

        }
    }
    }
    

